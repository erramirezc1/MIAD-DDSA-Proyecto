"""
Paquete para modelo de regresión lineal de importaciones.
"""
from .modelo import ModeloImportaciones

__version__ = "1.0.0"
__all__ = ["ModeloImportaciones"]

